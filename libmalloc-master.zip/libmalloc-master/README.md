# libmalloc
为了便于我们更好的学习苹果的底层的内存的分配，所以将苹果的[官方libmalloc源码](https://opensource.apple.com/tarballs/libmalloc/)编译好以便我们能够更好的去动态调试.

具体的步骤见简书：[libmalloc-166.200.60之源码编译](https://www.jianshu.com/p/cb1b573a0297)

或者下载工程文件：里面有一个配置的md说明文档
