//
//  AppDelegate.h
//  NMSample
//
//  Created by fengsl on 2020/8/25.
//  Copyright © Copyright © 2020 fengsl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

