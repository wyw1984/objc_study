//
//  main.m
//  NMSample
//
//  Created by fengsl on 2020/8/25.
//  Copyright © Copyright © 2020 fengsl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
