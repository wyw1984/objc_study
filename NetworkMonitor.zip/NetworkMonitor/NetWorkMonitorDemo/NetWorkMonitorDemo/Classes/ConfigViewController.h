//
//  ConfigViewController.h
//  NetworkMonitorSample
//
//  Created by fengsl on 2020/8/25.
//  Copyright © Copyright © 2020 fengsl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConfigViewController : UIViewController

@end
