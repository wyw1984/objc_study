//
//  NSURLConnectionDownloadDelegate.h
//  NetworkMonitorSample
//
//  Created by fengslon 2018/6/7.
//  Copyright © Copyright © 2020 fengsl. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURLConnectionDownloadDelegate : NSObject<NSURLConnectionDownloadDelegate>

@end
