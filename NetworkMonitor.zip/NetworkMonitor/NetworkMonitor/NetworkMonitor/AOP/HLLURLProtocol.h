//
//  HLLURLProtocol.h
//  HLLNetworkMonitor
//
//  Created by fengsl on 2020/8/27.
//  Copyright © 2020 fengsl. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HLLURLProtocol : NSURLProtocol

@end
