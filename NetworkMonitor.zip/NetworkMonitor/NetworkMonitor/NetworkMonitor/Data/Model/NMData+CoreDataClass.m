//
//  NMDATA+CoreDataClass.m
//  
//
//  Created by fengslon 2018/5/10.
//
//

#import "NMData+CoreDataClass.h"

@implementation NMData

@end
