//
//  NMDATA+CoreDataClass.h
//  
//
//  Created by fengslon 2018/5/10.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class NSObject;

NS_ASSUME_NONNULL_BEGIN

@interface NMData : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "NMData+CoreDataProperties.h"
